CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE NOT NULL
);

INSERT INTO customers (name, email) VALUES
    ('Jane Doe', 'jane@example.com'),
    ('John Smith', 'john.smith@example.com'),
    ('Alice Brown', 'alice.brown@example.com'),
    ('Bob Johnson', 'bob.johnson@example.com'),
    ('Charlie Davis', 'charlie.davis@example.com'),
    ('Diana Wilson', 'diana.wilson@example.com'),
    ('Eve White', 'eve.white@example.com'),
    ('Frank Green', 'frank.green@example.com');