from flask import Flask, jsonify
import psycopg2
import mysql.connector

app = Flask(__name__)

# Configuración de PostgreSQL
try:
    pg_conn = psycopg2.connect(
        host="postgres",
        database="mydatabase",
        user="myuser",
        password="mypassword"
    )
except Exception as e:
    app.logger.error(f"Error al conectar con PostgreSQL: {e}")
    raise

# Configuración de MySQL
try:
    mysql_conn = mysql.connector.connect(
        host="mysql",
        database="mydatabase",
        user="myuser",
        password="mypassword"
    )
except Exception as e:
    app.logger.error(f"Error al conectar con MySQL: {e}")
    raise

@app.route('/users', methods=['GET'])
def get_users():
    try:
        cur = pg_conn.cursor()
        cur.execute("SELECT * FROM users")
        users = cur.fetchall()
        cur.close()
        return jsonify(users)
    except Exception as e:
        app.logger.error(f"Error al obtener usuarios: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/customers', methods=['GET'])
def get_customers():
    try:
        cur = mysql_conn.cursor()
        cur.execute("SELECT * FROM customers")
        customers = cur.fetchall()
        cur.close()
        return jsonify(customers)
    except Exception as e:
        app.logger.error(f"Error al obtener clientes: {e}")
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)